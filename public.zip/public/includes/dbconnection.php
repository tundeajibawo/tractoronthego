<?php

$servername = "localhost";
$username = "nyben";
$password = "Nyben101";
$dbname = "togsales";


?>
